import {test,expect} from "@playwright/test";
import { ScrollPage } from "../../pages/ScrollPage";

test.describe('Scrolling to Element',()=>
    {
    test('scroll to element',async({page})=>
    {
        const scrollPage=new ScrollPage(page);
        await scrollPage.goto();
        await scrollPage.isLoaded();
        await scrollPage.scrollToLocator();

    })
})