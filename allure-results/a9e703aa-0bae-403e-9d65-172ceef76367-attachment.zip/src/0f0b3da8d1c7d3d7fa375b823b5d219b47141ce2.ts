import {Page,Locator,expect} from '@playwright/test';
import {BasePage_SOLID } from './BasePage_SOLID';

export class ScrollPage extends BasePage_SOLID
{
    readonly scrollToElement:Locator;

    constructor(page:Page)
    {
        super(page);
        this.scrollToElement=page.getByRole('heading',{name: 'Gifts to Sri Lanka - Best Sellers'});
    }
    async goto():Promise<void>
    {
        await this.navigate('/')
    }
    
     async isLoaded(): Promise<void> 
    {
        await this.scrollToElement.waitFor({state:"visible"});
        
    }
    async scrollToLocator():Promise<void>
    {
        await this.scrollLocator(this.scrollToElement)
    }
   
    }