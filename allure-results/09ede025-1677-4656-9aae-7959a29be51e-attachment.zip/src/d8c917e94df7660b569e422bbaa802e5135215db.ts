import {test,expect} from "@playwright/test";
import { ScrollPage } from "../../pages/ScrollPage";

test.describe('Kapruka Scrolling to Element',()=>
    {
    test('Scroll to specific element',async({page})=>
    {
        const scrollPage=new ScrollPage(page);
        await scrollPage.goto();
        await scrollPage.isLoaded();
        await scrollPage.scrollToHeader();

    })
})